clear;clc;
global reference
global W
global imgmean
global col_of_data
global pathname
global img_path_list

% 批量读取指定文件夹下的图片128*128
pathname = uigetdir;
img_path_list = dir(strcat(pathname,'\*.bmp'));% img_path_list=60*1 struct,60张图片信息
img_num = length(img_path_list);%60
imagedata = [];
if img_num >0
    for j = 1:img_num
        img_name = img_path_list(j).name;
        temp = imread(strcat(pathname, '/', img_name));
        temp = double(temp(:));
        imagedata = [imagedata, temp];
    end  % imagedata=16384*60
end
col_of_data = size(imagedata,2);
imgmean=mean(imagedata,2);% pca_1:average train data
for i = 1:col_of_data
    imagedata(:,i) = imagedata(:,i) - imgmean;
end
covMat=(imagedata'*imagedata)/60;%method 2
[~,latent,coeff]=svd(covMat);%svd求得的特征值，默认从大到小排列

row_of_data = size(imagedata,1);
coeff_initial=zeros(row_of_data,col_of_data);
for i = 1:col_of_data
    coeff_initial(:,i)=(1/(60*latent(i,i))^2)*imagedata*coeff(:,i);
end

totalvar = sum(latent);
explained = 100*latent/totalvar;

i=0;proportion = 0;
while(proportion < 95)
    i=i+1;
    proportion = proportion + explained(i);
end
p=i;

w=coeff_initial(:,1:p);

reference=w'*imagedata;